# RemoveWidgetBackground-Fixed

## iOS17 Patch
- Removed CHUISWidgetHostViewController interface style override.
- Keeps system colorScheme for third-party widgets.
